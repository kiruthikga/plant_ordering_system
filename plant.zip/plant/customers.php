<?php
$hostname = "localhost";
$database = "plant_ordering_system";
$username = "root";
$password = "";

$db = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);

$response = new stdClass();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle POST request (authenticate customer)
    $jsonBody = json_decode(file_get_contents('php://input'));

    try {
        // Assuming your 'customer' table has columns 'customer_username' and 'customer_password'
        $stmt = $db->prepare("SELECT * FROM customer WHERE cust_username = :username AND cust_password = :password");
        $stmt->bindParam(':username', $jsonBody->customer_username);
        $stmt->bindParam(':password', $jsonBody->customer_password);
        $stmt->execute();

        $customer = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($customer) {
            $response->authenticated = true;
            http_response_code(200);
        } else {
            $response->authenticated = false;
            http_response_code(401); // Unauthorized
        }
    } catch (Exception $e) {
        http_response_code(500);
        $response->error = "Error occurred: " . $e->getMessage();
    }
} else if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Handle GET request (retrieve all customer)
    try {
        $stmt = $db->prepare("SELECT * FROM customer");
        $stmt->execute();
        $response->data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        http_response_code(200);
    } catch (Exception $ee) {
        http_response_code(500);
        $response->error = "Error occurred: " . $ee->getMessage();
    }
}  


else {
    http_response_code(405); // Method Not Allowed
    $response->error = "Invalid method";
}

echo json_encode($response);
exit();
?>
