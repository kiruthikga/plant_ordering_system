<?php
$hostname = "localhost";
$database = "plant_ordering_system";
$username = "root";
$password = "";

$db = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);

$response = new stdClass();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle POST request (authenticate admin)
    $jsonBody = json_decode(file_get_contents('php://input'));

    try {
        // Assuming your 'admin' table has columns 'admin_username' and 'admin_password'
        $stmt = $db->prepare("SELECT * FROM admin WHERE admin_username = :username AND admin_password = :password");
        $stmt->bindParam(':username', $jsonBody->admin_username);
        $stmt->bindParam(':password', $jsonBody->admin_password);
        $stmt->execute();

        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin) {
            $response->authenticated = true;
            http_response_code(200);
        } else {
            $response->authenticated = false;
            http_response_code(401); // Unauthorized
        }
    } catch (Exception $e) {
        http_response_code(500);
        $response->error = "Error occurred: " . $e->getMessage();
    }
}  else if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Handle GET request (retrieve all admin)
    try {
        $stmt = $db->prepare("SELECT * FROM admin");
        $stmt->execute();
        $response->data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        http_response_code(200);
    } catch (Exception $ee) {
        http_response_code(500);
        $response->error = "Error occurred: " . $ee->getMessage();
    }
}  


else {
    http_response_code(405); // Method Not Allowed
    $response->error = "Invalid method";
}

echo json_encode($response);
exit();
?>
