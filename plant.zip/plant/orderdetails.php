<?php

$hostname = "localhost";
$database = "plant_ordering_system";
$username = "root";
$password = "";

$db = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);
$response = new stdClass();

$jsonbody = json_decode(file_get_contents('php://input'));

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if cust_id is present in JSON data
    if (isset($jsonbody->cust_id, $jsonbody->plant_id, $jsonbody->total)) {
        $plantid = $jsonbody->plant_id;
        $customerid = $jsonbody->cust_id;
        $total = $jsonbody->total;

        try {
            $stmt = $db->prepare("INSERT INTO order_details (plant_id, cust_id, total) VALUES (?, ?, ?)");
            $stmt->execute([$plantid, $customerid, $total]);

            $order_id = $db->lastInsertId();

            http_response_code(200);
            $response->message = "Order details created successfully.";
            $response->order_id = $order_id;
        } catch (Exception $ee) {
            http_response_code(500);
            $response->error = "Error occurred: " . $ee->getMessage();
        }
    } else {
        http_response_code(400);
        $response->error = "Invalid request: cust_id, plant_id, or total is missing.";
    }
}

header('Content-Type: application/json');
echo json_encode($response);
exit();

?>
