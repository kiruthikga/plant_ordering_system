<?php
$hostname = "localhost";
$database = "plant_ordering_system";
$username = "root";
$password = "";

$db = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);

$response = new stdClass();

// Function to send JSON response
function sendResponse($statusCode, $data) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Handle GET request (retrieve all plant)
    try {
        $stmt = $db->prepare("SELECT * FROM plant");
        $stmt->execute();
        $response->data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        http_response_code(200);
    } catch (Exception $ee) {
        http_response_code(500);
        $response->error = "Error occurred: " . $ee->getMessage();
    }
} else if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle POST request (add new plant)
    try {
        // Ensure that the image file is provided
        if (isset($_FILES['image']) && isset($_FILES['image']['name'])) {
            // Extract data from the request body
            $plantname = $_POST['plantname'];
            $planttype = $_POST['planttype'];
            $plantprice = $_POST['plantprice'];
            $plantquantity = $_POST['plantquantity'];
            $imageFileName = $_FILES['image']['name'];

            // Handle file upload
            $uploadsDir = __DIR__ . '/uploads/'; // Change this path to your desired uploads folder
            $uploadedFile = $uploadsDir . basename($_FILES['image']['name']);

            if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadedFile)) {
                // Insert the new plant into the database
                $stmt = $db->prepare("INSERT INTO plant (plant_name, plant_type, plant_price, plant_quantity, plant_image_name) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$plantname, $planttype, $plantprice, $plantquantity, $imageFileName]);

                $response->success = true;
                http_response_code(200);
            } else {
                $response->error = "Failed to upload the file";
                http_response_code(500);
            }
        } else {
            $response->error = "Image file not provided";
            http_response_code(400);
        }
    } catch (Exception $e) {
        $response->error = "Error occurred: " . $e->getMessage();
        http_response_code(500);
    }
} else if ($_SERVER["REQUEST_METHOD"] == "PUT") {
    try {
        // Read the request body
        $jsonbody = json_decode(file_get_contents("php://input"));

        if ($jsonbody) {
            // Update the plant details in the database based on plant_id
            $stmt = $db->prepare("UPDATE plant SET plant_name = ?, plant_type = ?, plant_price = ?, plant_quantity = ?, plant_image_name = ? WHERE plant_id = ?");
            $stmt->execute([$jsonbody->plantname, $jsonbody->planttype, $jsonbody->plantprice, $jsonbody->plantquantity, $jsonbody->plantimagename, $jsonbody->id]);

            // Check if a new image file is provided
            if (!empty($_FILES['image']['tmp_name'])) {
                $uploadPath = 'uploads/';
                $uploadedFile = $uploadPath . basename($_FILES['image']['name']);

                if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadedFile)) {
                    // Image uploaded successfully
                    http_response_code(200);
                    $response->success = true;
                    $response->message = "Plant details updated successfully.";
                    $response->plantimagename = $jsonbody->plantimagename;
                } else {
                    http_response_code(500);
                    $response->error = "Error uploading image file.";
                }
            } else {
                http_response_code(200);
                $response->success = true;
                $response->message = "Plant details updated successfully.";
                $response->plantimagename = $jsonbody->plantimagename;
            }
        } else {
            http_response_code(400);
            $response->error = "Invalid JSON format in the request body.";
        }
    } catch (Exception $ee) {
        http_response_code(500);
        $response->error = "Error occurred: " . $ee->getMessage();
    }
}  else if ($_SERVER["REQUEST_METHOD"] == "DELETE") {
    try {
        // Get the ID from the URL parameters
        $id = $_GET['id'] ?? null;

        if ($id) {
            // Get the image filename from the database before deleting the plant
            $stmt = $db->prepare("SELECT plant_image_name FROM plant WHERE plant_id = :id");
            $stmt->execute(array(':id' => $id));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $imageFilename = $row['plant_image_name'];

            // Delete the plant from the database
            $stmt = $db->prepare("DELETE FROM plant WHERE plant_id = :id");
            $stmt->execute(array(':id' => $id));

            // Check if any row was affected
            $rowsAffected = $stmt->rowCount();

            if ($rowsAffected > 0) {
                // Delete the image file from the uploads folder
                $imagePath = "uploads/" . $imageFilename;
                if (file_exists($imagePath)) {
                    unlink($imagePath);
                }

                sendResponse(200, array("message" => "Plant and associated image deleted successfully."));
            } else {
                sendResponse(404, array("error" => "Plant with given ID not found."));
            }
        } else {
            sendResponse(400, array("error" => "Invalid or missing ID in the request URL."));
        }
    } catch (Exception $ee) {
        sendResponse(500, array("error" => "Error occurred: " . $ee->getMessage()));
    }
}





echo json_encode($response);
exit();
?>
