<?php
$hostname = "localhost";
$database = "plant_ordering_system";
$username = "root";
$password = "";

$db = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);
$response = new stdClass();

// Decode JSON body for future use, even though it's not needed in the current code
$jsonbody = json_decode(file_get_contents('php://input'));

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Handle GET request (retrieve all add_to_cart for a specific customer ID)
    if (isset($_GET['customer_id'])) {
        $customerid = $_GET['customer_id'];
        try {
            $stmt = $db->prepare("SELECT * FROM add_to_cart JOIN plant ON add_to_cart.plant_id = plant.plant_id WHERE cust_id = ?");
            $stmt->execute([$customerid]);
            $response->data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            http_response_code(200);
        } catch (Exception $ee) {
            http_response_code(500);
            $response->error = "Error occurred: " . $ee->getMessage();
        }
    } else {
        http_response_code(400);
        $response->error = "Invalid request: customer_id is missing.";
    }
} else {
    http_response_code(405); // Method Not Allowed
    $response->error = "Invalid request method.";
}

// Set CORS headers if needed
// header("Access-Control-Allow-Origin: *");
// header("Access-Control-Allow-Methods: GET, OPTIONS");
// header("Access-Control-Allow-Headers: Content-Type");

// Send JSON response
echo json_encode($response);
exit();
?>
