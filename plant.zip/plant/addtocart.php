<?php
$hostname = "localhost";
$database = "plant_ordering_system";
$username = "root";
$password = "";

$db = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);
$response = new stdClass();

$jsonbody = json_decode(file_get_contents('php://input'));

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if customer_id is present in JSON data
    if (isset($jsonbody->customer_id)) {
        $plantid = $jsonbody->plant_id;
        $customerid = $jsonbody->customer_id;
        $quantity = $jsonbody->plant_quantity;
        $total = $jsonbody->total;

        try {
            $stmt = $db->prepare("INSERT INTO add_to_cart (plant_id, cust_id, plant_quantity, total) VALUES (?, ?, ?, ?)");
            $stmt->execute([$plantid, $customerid, $quantity, $total]);
            http_response_code(200);
            $response->message = "add to cart created successfully.";
        } catch (Exception $ee) {
            http_response_code(500);
            $response->error = "Error occurred: " . $ee->getMessage();
        }
    } else {
        http_response_code(400);
        $response->error = "Invalid request: customer_id is missing.";
    }
} else if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Handle GET request (retrieve all add_to_cart for a specific customer ID)
    if (isset($_GET['customer_id'])) {
        $customerid = $_GET['customer_id'];
        try {
            $stmt = $db->prepare("SELECT add_to_cart.*, plant.plant_id, plant.plant_name, plant.plant_type, plant.plant_price, plant.plant_image_name
FROM add_to_cart
JOIN plant ON add_to_cart.plant_id = plant.plant_id
WHERE cust_id = ?;");
            $stmt->execute([$customerid]);
            $response->data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            http_response_code(200);
        } catch (Exception $ee) {
            http_response_code(500);
            $response->error = "Error occurred: " . $ee->getMessage();
        }
    } else {
        http_response_code(400);
        $response->error = "Invalid request: customer_id is missing.";
    }
} else if ($_SERVER["REQUEST_METHOD"] == "DELETE") {
    // Handle DELETE request (delete an item from the cart)
    if (isset($_GET['plant_id'])) {
        $plantId = $_GET['plant_id']; // Add a semicolon at the end of the line

        try {
            $stmt = $db->prepare("DELETE FROM add_to_cart WHERE plant_id = ?");
            $stmt->execute([$plantId]); // Pass both parameters in the array
            http_response_code(200);
            $response->message = "Item deleted successfully.";
        } catch (Exception $ee) {
            http_response_code(500);
            $response->error = "Error occurred: " . $ee->getMessage();
        }
    } else {
        http_response_code(400);
        $response->error = "Invalid request: id is missing.";
    }
}
 else {
    http_response_code(405); // Method Not Allowed
    $response->error = "Invalid request method.";
}

echo json_encode($response);
exit();
?>
