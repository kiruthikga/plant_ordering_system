<?php
$hostname = "localhost";
$database = "plant_ordering_system";
$username = "root";
$password = "";

$db = new PDO("mysql:host=$hostname;dbname=$database", $username, $password);

$response = new stdClass();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle POST request for customer signup
    $jsonBody = json_decode(file_get_contents('php://input'));

    try {
        // Assuming your 'customer' table has columns 'cust_username', 'cust_password', 'cust_fullname', and 'cust_phoneno'
        $stmt = $db->prepare("INSERT INTO customer (cust_username, cust_password, cust_fullname, cust_phoneno) 
                              VALUES (:username, :password, :fullname, :phone)");

        $stmt->bindParam(':username', $jsonBody->customer_username);
        $stmt->bindParam(':password', $jsonBody->customer_password);
        $stmt->bindParam(':fullname', $jsonBody->customer_fullname);
        $stmt->bindParam(':phone', $jsonBody->phone_no);

        $stmt->execute();

        // Check if the signup was successful
        if ($stmt->rowCount() > 0) {
            $response->success = true;
            http_response_code(201); // Created
        } else {
            $response->success = false;
            $response->message = "Signup failed. Please check your input and try again.";
            http_response_code(400); // Bad Request
        }
    } catch (Exception $e) {
        http_response_code(500);
        $response->error = "Error occurred: " . $e->getMessage();
    }
} elseif ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Handle GET request (retrieve all customers)
    try {
        $stmt = $db->prepare("SELECT * FROM customer");
        $stmt->execute();
        $response->data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        http_response_code(200);
    } catch (Exception $ee) {
        http_response_code(500);
        $response->error = "Error occurred: " . $ee->getMessage();
    }
} else {
    http_response_code(405); // Method Not Allowed
    $response->error = "Invalid method";
}

echo json_encode($response);
exit();
?>
